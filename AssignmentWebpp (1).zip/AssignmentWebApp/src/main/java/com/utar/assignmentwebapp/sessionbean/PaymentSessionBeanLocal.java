package com.utar.assignmentwebapp.sessionbean;

import com.utar.assignmentwebapp.model.entity.Customer;
import com.utar.assignmentwebapp.model.entity.Orderdetail;
import com.utar.assignmentwebapp.model.entity.Payment;
import com.utar.assignmentwebapp.model.entity.PaymentId;

import javax.ejb.Local;
import java.util.List;

@Local
public interface PaymentSessionBeanLocal {

    public List<Payment> getAllPayment();
    public Payment findPayment(String id);
    //public List<Payment> findPayment(String cusId);
    public PaymentId findPaymentId(String id);
    public Customer findCustomer(String id);
    public int getNumberOfRows(String keyword);
    public void addPayment(String s[]);
    public void deletePayment(String id);
    public void updatePayment(String s[]);
    public List<Payment> readPaymentList(int currentPage, int recordsPerPage, String keyword, String direction);
}
