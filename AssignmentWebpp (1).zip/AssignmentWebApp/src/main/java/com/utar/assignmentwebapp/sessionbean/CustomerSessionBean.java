package com.utar.assignmentwebapp.sessionbean;

import com.utar.assignmentwebapp.model.entity.Customer;
import com.utar.assignmentwebapp.model.entity.Employee;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

@Stateless
public class CustomerSessionBean implements CustomerSessionBeanLocal{
    @PersistenceContext(unitName = "ProductWebApp")
    EntityManager em ;

    @Override
    public List<Customer> getAllCustomer() {
        Query q = null;
        q = em.createNativeQuery("SELECT * from classicmodels.customers");
        List<Customer> result = q.getResultList();
        return result;
    }

    @Override
    public Customer findCustomer(String id) {
        Query q = null;
        q = em.createNativeQuery("SELECT * from classicmodels.customers WHERE customernumber='"+id+"';" , Customer.class);
        return (Customer) q.getSingleResult();
    }

    @Override
    public Customer findNewestCust() {
        Query e =null;
        e=em.createNativeQuery("select * from classicmodels.customers ORDER BY customernumber desc LIMIT 1", Customer.class);
        return (Customer) e.getSingleResult();
    }

    @Override
    public int getNumberOfRows(String keyword) {
        Query q = null;
        if (keyword.isEmpty()) {
            q = em.createNativeQuery("SELECT COUNT(*) AS totalrow FROM classicmodels.customers");
        } else {
            q = em.createNativeQuery("SELECT COUNT(*) AS totalrow from classicmodels.customers WHERE concat(customerNumber, customerName, contactLastname, contactFirstName, phone, addressLine1, addressLine2, city, state, postalCode,country, salesRepEmployeeNumber, creditLimit) LIKE ?");
            q.setParameter(1, "%" + keyword + "%");
        }
        BigInteger results = (BigInteger) q.getSingleResult();
        int i = results.intValue();
        return i;
    }

    @Override
    public void updateCustomer(String[] s) {
        Customer cust = findCustomer(s[0]);
        Employee employee = new Employee();
        employee.setId(Integer.valueOf(s[11]));

        cust.setCustomername(s[1]);
        cust.setContactlastname(s[2]);
        cust.setContactfirstname(s[3]);
        cust.setPhone(s[4]);
        cust.setAddressline1(s[5]);
        cust.setAddressline2(s[6]);
        cust.setCity(s[7]);
        cust.setState(s[8]);
        cust.setPostalcode(s[9]);
        cust.setCountry(s[10]);
        cust.setSalesrepemployeenumber(employee);
        cust.setCreditlimit(BigDecimal.valueOf(Double.parseDouble(s[12])));
        em.merge(cust);

    }

    @Override
    public void deleteCustomer(int id) {
        Customer delete = findCustomer(String.valueOf(id));
        em.remove(delete);
    }

    @Override
    public void addCustomer(String[] s) {
        Customer cust = new Customer();
        Employee employee = new Employee();
        employee.setId(Integer.valueOf(s[11]));

        cust.setId(Integer.valueOf(s[0]));
        cust.setCustomername(s[1]);
        cust.setContactlastname(s[2]);
        cust.setContactfirstname(s[3]);
        cust.setPhone(s[4]);
        cust.setAddressline1(s[5]);
        cust.setAddressline2(s[6]);
        cust.setCity(s[7]);
        cust.setState(s[8]);
        cust.setPostalcode(s[9]);
        cust.setCountry(s[10]);
        cust.setSalesrepemployeenumber(employee);
        cust.setCreditlimit(BigDecimal.valueOf(Double.parseDouble(s[12])));
        em.persist(cust);
    }

    @Override
    public List<Customer> readCustomerList(int currentPage, int recordsPerPage, String keyword, String direction) {
        Query q = null;
        int start = 0;
        direction = " " + direction;
        if (keyword.isEmpty()) {
            q = em.createNativeQuery("SELECT * FROM classicmodels.customers order by customerNumber" + direction, Customer.class);
            start = currentPage * recordsPerPage - recordsPerPage;
        } else {
            q = em.createNativeQuery("SELECT * from classicmodels.customers WHERE concat(customerNumber, customerName, contactLastname, contactFirstName, phone, addressLine1, addressLine2, city, state, postalCode,country, salesRepEmployeeNumber, creditLimit) LIKE ? order by customerNumber" + direction, Customer.class);
            start = currentPage * recordsPerPage - recordsPerPage;
            q.setParameter(1, "%" + keyword + "%");
        }
        List<Customer> results = q.setFirstResult(start).setMaxResults(recordsPerPage).getResultList();
        return results;
    }
}
