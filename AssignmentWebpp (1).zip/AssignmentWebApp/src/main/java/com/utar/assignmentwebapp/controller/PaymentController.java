package com.utar.assignmentwebapp.controller;

import com.utar.assignmentwebapp.model.entity.Payment;
import com.utar.assignmentwebapp.sessionbean.PaymentSessionBeanLocal;
import com.utar.assignmentwebapp.utilities.ValidatePaymentManageLogic;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "PaymentController", value = "/PaymentController")
public class PaymentController extends HttpServlet{

    @EJB
    private PaymentSessionBeanLocal empbean;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String checknumber = request.getParameter("checknumber");
        try {
            Payment payment = empbean.findPayment(checknumber);
            request.setAttribute("payment", payment);
            RequestDispatcher req = request.getRequestDispatcher("payView.jsp");
            req.forward(request, response);
        } catch (EJBException ex) {
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String customernumber = request.getParameter("customernumber");
        String checknumber= request.getParameter("checknumber");
        String paymentdate = request.getParameter("paymentdate");
        String amount= request.getParameter("amount");
        PrintWriter out = response.getWriter();


        String[] s = {checknumber,customernumber,paymentdate,amount};

        try {
            if (ValidatePaymentManageLogic.validateManager(request).equals("UPDATE")) {
                empbean.updatePayment(s);
            }
            else if (ValidatePaymentManageLogic.validateManager(request).equals("DELETE")) {
                empbean.deletePayment(checknumber);
            }
            else{
                empbean.addPayment(s);
                ValidatePaymentManageLogic.navigateDoneJS(out);
            }
            ValidatePaymentManageLogic.navigateJS(out);
        } catch (EJBException ex) {
            ValidatePaymentManageLogic.navigateWrongJS(out);
        }




    }
}
