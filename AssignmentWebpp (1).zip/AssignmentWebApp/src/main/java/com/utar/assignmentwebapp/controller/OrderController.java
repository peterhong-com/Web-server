package com.utar.assignmentwebapp.controller;




import com.utar.assignmentwebapp.model.entity.Order;
import com.utar.assignmentwebapp.sessionbean.OrderSessionBeanLocal;
import com.utar.assignmentwebapp.utilities.ValidateOrderManageLogic;
import org.hibernate.Session;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet(name = "OrderController", value = "/OrderController")
public class OrderController extends HttpServlet {
    @EJB
    private OrderSessionBeanLocal empbean;
    Order ord;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ordernumber = request.getParameter("id");
        try {
            Order order = empbean.readOrder(Integer.parseInt(ordernumber));
            request.setAttribute("order", order);
            RequestDispatcher req = request.getRequestDispatcher("orderUpdate.jsp");
            req.forward(request, response);
        } catch (EJBException ex) {
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ordernumber = request.getParameter("ordernumber");
        String customernumber = "103";
        String orderdate= request.getParameter("orderdate");
        String comments = request.getParameter("comments");
        String shippeddate = request.getParameter("shippeddate");
        String requireddate = request.getParameter("requireddate");
        String status = "Shipped";
        ArrayList<String> productId = (ArrayList<String>) request.getSession().getAttribute("list");
        ArrayList<Double> quantity =(ArrayList<Double>) request.getSession().getAttribute("quantitylist");
        PrintWriter out = response.getWriter();

        String[] s = {ordernumber,customernumber,orderdate,comments,shippeddate,requireddate,status};

        try {
            if (ValidateOrderManageLogic.validateManager(request).equals("UPDATE")) {
                empbean.updateOrder(s);
            }
            else if (ValidateOrderManageLogic.validateManager(request).equals("DELETE")) {
                empbean.deleteOrder(Integer.parseInt(s[0]));
            } else {
            }
            ValidateOrderManageLogic.navigateJS(out);
        } catch (EJBException ex) {
        }




    }
}


