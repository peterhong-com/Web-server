package com.utar.assignmentwebapp.controller;


import com.utar.assignmentwebapp.model.entity.Orderdetail;
import com.utar.assignmentwebapp.sessionbean.OrderDetailSessionBeanLocal;
import com.utar.assignmentwebapp.utilities.ValidateOrderDetailManageLogic;
import com.utar.assignmentwebapp.utilities.ValidateOrderManageLogic;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.ArrayList;

@WebServlet(name = "OrderDetailController", value = "/OrderDetailController")
public class OrderDetailController extends HttpServlet {
    @EJB
    private OrderDetailSessionBeanLocal empbean;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ordernumber = request.getParameter("ordernumber");
        String product= request.getParameter("productcode");
        try {
            Orderdetail orderdetail = empbean.readOrderDetail(Integer.parseInt(ordernumber),product);
            request.setAttribute("orderdetail", orderdetail);
            RequestDispatcher req = request.getRequestDispatcher("orderDetailUpdate.jsp");
            req.forward(request, response);
        } catch (EJBException ex) {
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String ordernumber = request.getParameter("ordernumber");
        Integer order= (Integer)request.getAttribute("ordernumber");
        String productcode = request.getParameter("productcode");
        String orderlinenumber= request.getParameter("orderlinenumber");
        String priceeach = request.getParameter("priceeach");
        String quantityordered = request.getParameter("quantityordered");
        PrintWriter out = response.getWriter();



        String[] s = {ordernumber,productcode,orderlinenumber,priceeach,quantityordered};

        try {
            if (ValidateOrderManageLogic.validateManager(request).equals("UPDATE")) {

                empbean.updateOrderDetail(s);
            }
            else if (ValidateOrderManageLogic.validateManager(request).equals("DELETE")) {

                empbean.deleteOrderDetail(Integer.parseInt(s[0]),s[1]);

            } else {

                ArrayList<String> productList= (ArrayList<String>) request.getSession().getAttribute("prolist");
                ArrayList<Integer> Quantity=(ArrayList<Integer>) request.getSession().getAttribute("quantitylist");
                ArrayList<BigDecimal> pricelist=(ArrayList<BigDecimal>) request.getSession().getAttribute("pricelist");
                System.out.println(pricelist);
                for(int i=0; i<pricelist.size();i++) {
                    String[] a =  {order.toString(),productList.get(i),"1",pricelist.get(i).toString(),Quantity.get(i).toString()};
                    empbean.addOrderDetail(a);
                }
                request.getSession().removeAttribute("prolist");
                request.getSession().removeAttribute("quantitylist");
                request.getSession().removeAttribute("pricelist");
                ValidateOrderDetailManageLogic.navigateJSa(out);
            }

            ValidateOrderDetailManageLogic.navigateJS(out);
        } catch (EJBException ex) {
        }
    }
}
