package com.utar.assignmentwebapp.sessionbean;



import com.utar.assignmentwebapp.model.entity.Order;
import com.utar.assignmentwebapp.model.entity.Orderdetail;
import com.utar.assignmentwebapp.model.entity.Product;

import javax.ejb.Local;
import java.util.List;

@Local
public interface OrderDetailSessionBeanLocal {
    public List<Orderdetail> getAllOrderDetail();
    public Orderdetail readOrderDetail(int orderId,String productCode);
    public void deleteOrderDetail(int orderId,String productCode);
    public void addOrderDetail(String[] s);
    public void updateOrderDetail(String[] s);
    public List<Orderdetail> findOrderDetailList(int ordId);
    public List<Orderdetail> readOrderDetailList(int currentPage, int recordsPerPage, String keyword, String direction);
    public int getNumberOfRows(String keyword);
    public Product findproduct(String productcode);
    public Order findOrder(String orderNumber);

}
