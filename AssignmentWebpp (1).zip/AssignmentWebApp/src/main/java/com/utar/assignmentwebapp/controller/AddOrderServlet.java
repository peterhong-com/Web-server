package com.utar.assignmentwebapp.controller;

import com.utar.assignmentwebapp.model.entity.Order;
import com.utar.assignmentwebapp.sessionbean.OrderSessionBeanLocal;

import javax.ejb.EJB;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet(name = "AddOrderServlet", value = "/AddOrderServlet")
public class AddOrderServlet extends HttpServlet {
    @EJB
    private OrderSessionBeanLocal empbean;
    Order ord;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        String customernumber = "103";
        String orderdate= request.getParameter("orderdate");
        String comments = request.getParameter("comments");
        String shippeddate = request.getParameter("shippeddate");
        String requireddate = request.getParameter("requireddate");
        String status = "Shipped";
        ArrayList<String> productId = (ArrayList<String>) request.getSession().getAttribute("list");
        ArrayList<Double> quantity =(ArrayList<Double>) request.getSession().getAttribute("quantitylist");
        PrintWriter out = response.getWriter();
        ord=empbean.findNewestOrder();
        int ordernumber=ord.getId()+1;
        String[] s = {String.valueOf(ordernumber),customernumber,orderdate,comments,shippeddate,requireddate,status};empbean.addOrder(s);
        RequestDispatcher dd = request.getRequestDispatcher("OrderDetailController");
        request.setAttribute("ordernumber",ordernumber);
        dd.forward(request,response);
    }
}
