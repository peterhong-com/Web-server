package com.utar.assignmentwebapp.sessionbean;

import com.utar.assignmentwebapp.model.entity.Product;

public interface CartSessionBeanLocal {
    public Product findProduct(String id);
    public void createTable();
    public void addCart(String[] s,Double[]y);

}
