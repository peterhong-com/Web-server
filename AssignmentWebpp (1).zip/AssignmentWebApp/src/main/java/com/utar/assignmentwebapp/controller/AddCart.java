package com.utar.assignmentwebapp.controller;

import com.utar.assignmentwebapp.model.entity.Product;
import com.utar.assignmentwebapp.sessionbean.ProductSessionBeanLocal;

import javax.ejb.EJB;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "AddCart", value = "/AddCart")
public class AddCart extends HttpServlet {
    @EJB
    ProductSessionBeanLocal empbean;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String aa =request.getParameter("product");
        Product pro= empbean.findProduct(aa);
        RequestDispatcher req = request.getRequestDispatcher("AddCart.jsp");
        request.setAttribute("product1",pro);
        req.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
