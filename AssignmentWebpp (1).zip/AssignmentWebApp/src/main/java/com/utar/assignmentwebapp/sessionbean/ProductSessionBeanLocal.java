package com.utar.assignmentwebapp.sessionbean;

import com.utar.assignmentwebapp.model.entity.Product;

import javax.ejb.Local;
import java.util.List;

@Local
public interface ProductSessionBeanLocal {
    public List<Product> getAllProduct();
    public Product findProduct(String id);
    public int getNumberOfRows(String keyword);
    public void deleteProduct(String productcode);
    public void addProduct(String s[]);
    public void updateProduct(String s[]);
    public List<Product> readProductList(int currentPage, int recordsPerPage, String keyword, String direction);
}
