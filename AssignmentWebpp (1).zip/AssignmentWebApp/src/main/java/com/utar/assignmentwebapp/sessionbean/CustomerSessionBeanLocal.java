package com.utar.assignmentwebapp.sessionbean;

import com.utar.assignmentwebapp.model.entity.Customer;

import javax.ejb.Local;
import java.util.List;

@Local
public interface CustomerSessionBeanLocal {
    public List<Customer> getAllCustomer();
    public Customer findCustomer(String id);
    public Customer findNewestCust();
    public int getNumberOfRows(String keyword);
    public void updateCustomer(String[]s);
    public void deleteCustomer(int id);
    public void addCustomer(String[]s);
    public List<Customer> readCustomerList(int currentPage, int recordsPerPage, String keyword, String direction);
}
