package com.utar.assignmentwebapp.sessionbean;

import com.utar.assignmentwebapp.model.entity.Employee;
import com.utar.assignmentwebapp.model.entity.Office;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigInteger;
import java.util.List;

@Stateless
public class EmployeeSessionBean implements EmployeeSessionBeanLocal {
    @PersistenceContext(unitName = "ProductWebApp")
    EntityManager em ;
    @Override
    public List<Employee> getAllEmployee() {
        Query q = null;
        q = em.createNativeQuery("SELECT * from classicmodels.employees");
        List<Employee> result = q.getResultList();
        return result;
    }

    @Override
    public List<Employee> readEmployee(int currentPage, int recordsPerPage, String keyword, String direction) {
        Query q = null;
        int start = 0;
        direction = " " + direction;
        if (keyword.isEmpty()) {
            q = em.createNativeQuery("SELECT * FROM classicmodels.employees order by employeeNumber" + direction, Employee.class);
            start = currentPage * recordsPerPage - recordsPerPage;
        } else {
            q = em.createNativeQuery("SELECT * from classicmodels.employees WHERE concat(employeenumber, lastname, firstname, extension, email,reportsto,jobtitle) LIKE ? order by employeeNumber" + direction, Employee.class);
            start = currentPage * recordsPerPage - recordsPerPage;
            q.setParameter(1, "%" + keyword + "%");
        }
        List<Employee> results = q.setFirstResult(start).setMaxResults(recordsPerPage).getResultList();
        return results;
    }

    @Override
    public Employee findEmployee(Integer id) {

        Query q = null;
        q = em.createNativeQuery("SELECT * from classicmodels.employees WHERE employeenumber='"+id+"';" , Employee.class);
        return (Employee) q.getSingleResult();
    }

    @Override
    public int getNumberOfRows(String keyword) {
        Query q = null;
        if (keyword.isEmpty()) {
            q = em.createNativeQuery("SELECT COUNT(*) AS totalrow FROM classicmodels.employees");
        } else {
            q = em.createNativeQuery("SELECT COUNT(*) AS totalrow from classicmodels.employees WHERE concat(employeenumber, firstname, lastname, extension, email,reportsto,jobtitle) LIKE ?");
            q.setParameter(1, "%" + keyword + "%");
        }
        BigInteger results = (BigInteger) q.getSingleResult();
        int i = results.intValue();
        return i;
    }

    @Override
    public void deleteEmployee(Integer id) {
        Employee delete = findEmployee(id);
        em.remove(delete);

    }

    @Override
    public void addEmployee(String[] s) {
        Employee employee = new Employee();
        Office office = new Office();
        office.setId(Integer.valueOf(s[5]));

        employee.setId(Integer.valueOf(s[0]));
        employee.setFirstname(s[1]);
        employee.setLastname(s[2]);
        employee.setExtension(s[3]);
        employee.setEmail(s[4]);
        employee.setOffices(office);
        employee.setReportsto(s[6]);
        employee.setJobtitle(s[7]);
        em.persist(employee);
    }
    @Override
    public void updateEmployee(String[] s) {
        Employee employee = findEmployee(Integer.valueOf(s[0]));
        Office office = new Office();
        office.setId(Integer.valueOf(s[5]));

        employee.setFirstname(s[1]);
        employee.setLastname(s[2]);
        employee.setExtension(s[3]);
        employee.setEmail(s[4]);
        employee.setOffices(office);
        employee.setReportsto(s[6]);
        employee.setJobtitle(s[7]);
        em.merge(employee);
    }


}
