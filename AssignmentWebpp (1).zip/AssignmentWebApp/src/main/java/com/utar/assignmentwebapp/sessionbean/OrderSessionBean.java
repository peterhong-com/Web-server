package com.utar.assignmentwebapp.sessionbean;



import com.utar.assignmentwebapp.model.entity.Order;


import javax.ejb.EJBException;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigInteger;
import java.util.List;

@Stateless
public class OrderSessionBean implements OrderSessionBeanLocal {
    @PersistenceContext(unitName = "ProductWebApp")
    EntityManager em;
    @Override
    public List<Order> getAllOrder() {
        Query q = null;
        q = em.createNativeQuery("SELECT * from classicmodels.orders");
        List<Order> result=q.getResultList();
        return result;
    }
    @Override public List<Order> readOrderList(int currentPage, int recordsPerPage, String keyword, String direction) throws EJBException {
        Query q = null; int start = 0; direction = " " + direction;
        if (keyword.isEmpty()) {
            q = em.createNativeQuery("SELECT * FROM classicmodels.orders order by ordernumber"+ direction, Order.class);
            start = currentPage * recordsPerPage - recordsPerPage;
        }
        else {
        q = em.createNativeQuery("SELECT * from classicmodels.orders WHERE concat(ordernumber,requireddate,status,shippeddate,comments,customernumber) LIKE ? order by ordernumber" + direction,Order.class);
        start = currentPage * recordsPerPage - recordsPerPage;
        q.setParameter(1, "%" + keyword + "%");
        }
        List<Order> results = q.setFirstResult(start).setMaxResults(recordsPerPage).getResultList(); return results; }
    @Override
    public Order readOrder(int orderId) {
        Query q = null;
        q = em.createNativeQuery("SELECT * from classicmodels.orders WHERE ordernumber = "+orderId, Order.class);
        return (Order)q.getSingleResult();

    }
    @Override
    public int getNumberOfRows(String keyword) throws EJBException { Query q = null;
        if (keyword.isEmpty()) {
        q = em.createNativeQuery("SELECT COUNT(*) AS totalrow FROM classicmodels.orders"); }
    else { q = em.createNativeQuery("SELECT COUNT(*) AS totalrow from classicmodels.orders WHERE concat(ordernumber,requireddate,status,shippeddate,comments,customernumber) LIKE ?");
        q.setParameter(1, "%" + keyword + "%"); }
        BigInteger results = (BigInteger) q.getSingleResult();
        int i = results.intValue(); return i; }
    public int getNumberOfOrderRows(int cusId) throws EJBException { Query q = null;

            q = em.createNativeQuery("SELECT COUNT(*) AS totalrow FROM classicmodels.orders where customernumber="+cusId);

        BigInteger results = (BigInteger) q.getSingleResult();
        int i = results.intValue(); return i; }

    @Override
    public void deleteOrder(int orderId) {
        Order delete = readOrder(orderId);
        em.remove(delete);
    }

    @Override
    public void cancellShippingOrder(int OrderId) {
        Order cancel= readOrder(OrderId);
        cancel.setStatus("Cancelled");
        em.merge(cancel);
    }


    @Override
    public Order findNewestOrder(){
        Query e =null;
        e=em.createNativeQuery("select * from classicmodels.orders ORDER BY ordernumber desc LIMIT 1",Order.class);
        return (Order) e.getSingleResult();
    }

    @Override
    public void updateOrder(String[] s) throws EJBException {


        Order e = readOrder(Integer.parseInt(s[0]));

        e.setCustomernumber((int) Short.parseShort(s[1]));
        e.setOrderdate(s[2]);
        e.setComments(s[3]);
        e.setShippeddate(s[4]);
        e.setRequireddate(s[5]);
        e.setStatus(s[6]);
        em.merge(e);
    }
    @Override
    public List<Order> findOrderList(int cus,int currentPage, int recordsPerPage,  String direction){
            Query q= null;
        q = em.createNativeQuery("SELECT * from classicmodels.orders WHERE customernumber=" +cus+" order by ordernumber " + direction,Order.class);
        int start = currentPage * recordsPerPage - recordsPerPage;
    List<Order> results = q.setFirstResult(start).setMaxResults(recordsPerPage).getResultList();
    return results;
    }

    @Override
    public void addOrder(String[] s) throws EJBException {

        Order e = new Order();
        e.setId(Integer.parseInt(s[0]));
        e.setCustomernumber(Integer.parseInt(s[1]));
        e.setOrderdate(s[2]);
        e.setComments(s[3]);
        e.setShippeddate(s[4]);
        e.setRequireddate(s[5]);
        e.setStatus(s[6]);
        em.persist(e);
    }

}

