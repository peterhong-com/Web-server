package com.utar.assignmentwebapp.controller;

import com.utar.assignmentwebapp.model.entity.Order;
import com.utar.assignmentwebapp.sessionbean.OrderSessionBeanLocal;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "CustomerOrderServlet", value = "/CustomerOrderServlet")
public class CustomerOrderServlet extends HttpServlet {
    @EJB
    OrderSessionBeanLocal orderbean;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int nOfPages = 0;
        int currentPage = Integer.parseInt(request.getParameter("currentPage"));
        System.out.println(currentPage+request.getParameter("recordsPerPage"));
        int recordsPerPage = Integer.parseInt(request.getParameter("recordsPerPage"));
        String keyword = "";
        String direction = request.getParameter("direction");
        try {
            int rows = orderbean.getNumberOfOrderRows(103);
            nOfPages = rows / recordsPerPage;
            if (rows % recordsPerPage != 0) {
                nOfPages++;
            }
            if (currentPage > nOfPages && nOfPages != 0) {
                currentPage = nOfPages;
            }

            List<Order> lists = orderbean.findOrderList(103,1, recordsPerPage, direction);
            request.setAttribute("order", lists);
        } catch (EJBException ex) {
        }

        request.setAttribute("nOfPages", nOfPages);
        request.setAttribute("currentPage", currentPage);
        request.setAttribute("recordsPerPage", recordsPerPage);
        request.setAttribute("direction", direction);
        RequestDispatcher dispatcher = request.getRequestDispatcher("customerOrderPaganition.jsp");
        dispatcher.forward(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
