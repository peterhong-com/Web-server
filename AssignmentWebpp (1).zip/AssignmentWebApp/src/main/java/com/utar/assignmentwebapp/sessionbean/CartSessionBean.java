package com.utar.assignmentwebapp.sessionbean;

import com.utar.assignmentwebapp.model.entity.Product;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

public class CartSessionBean implements CartSessionBeanLocal{
    @PersistenceContext(unitName = "ProductWebApp")
    EntityManager em;

    @Override
    public Product findProduct(String id) {
        Query q = null;
        q = em.createNativeQuery("SELECT * from classicmodels.products WHERE productcode = '" + id + "'", Product.class);
        return (Product) q.getSingleResult();
    }
    @Override
    public void createTable() {
        Query q = null;
        String sql = "CREATE TABLE cart (id INT PRIMARY KEY, productname VARCHAR(50), priceperunit DOUBLE,quantity DOUBLE)";
        q  = em.createNativeQuery(sql);
        q.executeUpdate();

    }
    @Override
    public void addCart(String[] s, Double[] y) {

        String insertDataSql = "INSERT INTO customers (id, productname, priceperunit, quantity) VALUES (" + s +y+")";
        Query insertDataQuery = em.createNativeQuery(insertDataSql);
        insertDataQuery.executeUpdate();
    }



}
