package com.utar.assignmentwebapp.controller;

import com.utar.assignmentwebapp.model.entity.Product;
import com.utar.assignmentwebapp.sessionbean.ProductSessionBeanLocal;
import com.utar.assignmentwebapp.utilities.ValidateProductManageLogic;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ProductController", value = "/ProductController")
public class ProductController extends HttpServlet {

    @EJB
    private ProductSessionBeanLocal empbean;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productcode = request.getParameter("productcode");
        try {
            Product product = empbean.findProduct(productcode);
            request.setAttribute("Pro", product);
            RequestDispatcher req = request.getRequestDispatcher("productUpdate.jsp");
            req.forward(request, response);
        } catch (EJBException ex) {
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pid = request.getParameter("productcode");
        String pname = request.getParameter("productname");
        String pscale = request.getParameter("productscale");
        String pvendor = request.getParameter("productvendor");
        String pproductline = request.getParameter("productline");
        String pdescription = request.getParameter("productdescription");
        String pquantityinstock = request.getParameter("quantityinstock");
        String pbuyprice = request.getParameter("buyprice");
        String pmsrp = request.getParameter("msrp");

        PrintWriter out = response.getWriter();
        // this line is to package the whole values into one array string variable -
        // easier just pass one parameter object
        String[] s = { pid,pname,pscale,pvendor,pdescription,pquantityinstock,pbuyprice,pmsrp,pproductline};


        try {
            if (ValidateProductManageLogic.validateManager(request).equals("UPDATE")) {
                // call session bean updateEmployee method
              empbean.updateProduct(s);

            }
            else if (ValidateProductManageLogic.validateManager(request).equals("DELETE")) {
               // call session bean deleteEmployee method
                    empbean.deleteProduct(pid);
               // if ADD button is clicked
           } else if (ValidateProductManageLogic.validateManager(request).equals("ADD")){
                // call session bean addEmployee method
               empbean.addProduct(s);
            }
            // this line is to redirect to notify record has been updated and redirect to
            // another page
            ValidateProductManageLogic.navigateJS(out);
        } catch (EJBException ex) {
            ValidateProductManageLogic.navigateWrongJS(out);
        }
    }
}
