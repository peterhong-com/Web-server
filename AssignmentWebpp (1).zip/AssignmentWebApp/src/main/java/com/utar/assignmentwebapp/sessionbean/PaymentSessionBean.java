package com.utar.assignmentwebapp.sessionbean;

import com.utar.assignmentwebapp.model.entity.Customer;
import com.utar.assignmentwebapp.model.entity.Payment;
import com.utar.assignmentwebapp.model.entity.PaymentId;

import javax.ejb.EJBException;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

@Stateless
public class PaymentSessionBean implements PaymentSessionBeanLocal {

    @PersistenceContext(unitName = "ProductWebApp")
    EntityManager em ;

    @Override
    public List<Payment> getAllPayment() {
        Query q = null;
        q = em.createNativeQuery("SELECT * from classicmodels.payments");
        List<Payment> result = q.getResultList();
        return result;
    }

//    @Override
//    public List<Payment> findPayment(String cusId) {
//        Query q = null;
//        q=em.createNativeQuery("SELECT * FROM classicmodels.payments where customernumber="+cusId);
//        return q.getResultList();
//    }


    @Override
    public Payment findPayment(String id) {
        Query q = null;
        q = em.createNativeQuery("SELECT * from classicmodels.payments WHERE checknumber='"+id+"';" , Payment.class);
        return (Payment) q.getSingleResult();
    }

    @Override
    public PaymentId findPaymentId(String id) {
        Query q =null;
        q=em.createNativeQuery("SELECT * from classicmodels.payments WHERE checknumber='"+id +"';", PaymentId.class);
        return (PaymentId) q.getSingleResult();
    }

    @Override
    public Customer findCustomer(String id) {
        Query q = null;
        q = em.createNativeQuery("SELECT * from classicmodels.customers WHERE customernumber='"+id +"';", Customer.class);
        return (Customer) q.getSingleResult();
    }


    @Override
    public int getNumberOfRows(String keyword) {
        Query q = null;
        if (keyword.isEmpty()) {
            q = em.createNativeQuery("SELECT COUNT(*) AS totalrow FROM classicmodels.payments");
        } else {
            q = em.createNativeQuery("SELECT COUNT(*) AS totalrow from classicmodels.payments WHERE concat(customerNumber, checknumber, paymentdate, amount) LIKE ?");
            q.setParameter(1, "%" + keyword + "%");
        }
        BigInteger results = (BigInteger) q.getSingleResult();
        int i = results.intValue();
        return i;
    }

    @Override
    public void addPayment(String[] s) {
        PaymentSessionBeanLocal aa = this;
        Payment e =  new Payment();
        PaymentId a = new PaymentId();
        Customer b = aa.findCustomer(s[1]);

        a.setChecknumber(s[0]);

        e.setCustomernumber(b);
        e.setPaymentdate(s[2]);
        e.setAmount(BigDecimal.valueOf(Double.parseDouble(s[3])));

        PaymentId ab = new PaymentId();
        ab.setCustomernumber(b.getId());
        ab.setChecknumber(a.getChecknumber());
        e.setId(ab);
        em.persist(e);
    }

    @Override
    public void deletePayment(String id) {
        Payment delete = findPayment(id);
        em.remove(delete);
    }

    @Override
    public void updatePayment(String[] s) throws EJBException {
        //PaymentSessionBeanLocal aa = this;
        Payment e =  findPayment(s[0]);

        //e.getId().setChecknumber(s[0]);
        e.setPaymentdate(s[2]);
        e.setAmount(BigDecimal.valueOf(Double.parseDouble(s[3])));

        em.merge(e);
    }

    @Override
    public List<Payment> readPaymentList(int currentPage, int recordsPerPage, String keyword, String direction) {
        Query q = null;
        int start = 0;
        direction = " " + direction;
        if (keyword.isEmpty()) {
            q = em.createNativeQuery("SELECT * FROM classicmodels.payments order by customerNumber" + direction, Payment.class);
            start = currentPage * recordsPerPage - recordsPerPage;
        } else {
            q = em.createNativeQuery("SELECT * from classicmodels.payments WHERE concat(customerNumber, checknumber, paymentdate, amount) LIKE ? order by customerNumber" + direction, Payment.class);
            start = currentPage * recordsPerPage - recordsPerPage;
            q.setParameter(1, "%" + keyword + "%");
        }
        List<Payment> results = q.setFirstResult(start).setMaxResults(recordsPerPage).getResultList();
        return results;
    }
}
