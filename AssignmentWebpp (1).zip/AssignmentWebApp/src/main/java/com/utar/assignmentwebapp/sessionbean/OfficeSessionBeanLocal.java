package com.utar.assignmentwebapp.sessionbean;


import com.utar.assignmentwebapp.model.entity.Office;

import javax.ejb.Local;
import java.util.List;
@Local
public interface OfficeSessionBeanLocal {
    public List<Office> getAllOffice();
    public Office findOffice(Integer id) ;
    public List<Office> readOffice(int currentPage, int recordsPerPage, String keyword, String direction);
    public int getNumberOfRows(String keyword) ;
    public void updateOffice(String[] s) ;
    public void deleteOffice(Integer id) ;
    public void addOffice(String[] s) ;
}
