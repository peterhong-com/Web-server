package com.utar.assignmentwebapp.controller;

import com.utar.assignmentwebapp.model.entity.Order;
import com.utar.assignmentwebapp.model.entity.Orderdetail;
import com.utar.assignmentwebapp.sessionbean.OrderDetailSessionBeanLocal;

import javax.ejb.EJB;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "ReadOrderDetailServlet", value = "/ReadOrderDetailServlet")
public class ReadOrderDetailServlet extends HttpServlet {
    @EJB
    private OrderDetailSessionBeanLocal ord;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       List<Orderdetail> ordd = ord.findOrderDetailList(Integer.parseInt(request.getParameter("ordernumber")));
        request.setAttribute("orderdetail1",ordd);
        RequestDispatcher req = request.getRequestDispatcher("customerOrderDetail.jsp");
        req.forward(request,response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
