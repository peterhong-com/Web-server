package com.utar.assignmentwebapp.controller;



import com.utar.assignmentwebapp.model.entity.Orderdetail;
import com.utar.assignmentwebapp.sessionbean.OrderDetailSessionBeanLocal;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "OrderDetailPaginationServlet", value = "/OrderDetailPaginationServlet")
public class OrderDetailPaginationServlet extends HttpServlet {

    @EJB
    private OrderDetailSessionBeanLocal orderdetailbean;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int nOfPages= 0;
        int currentPage = Integer.parseInt(request.getParameter("currentPage"));
        int recordsPerPage = Integer.parseInt(request.getParameter("recordsPerPage"));
        String keyword = request.getParameter("keyword");
        String direction = request.getParameter("direction");
        try {
            int rows = orderdetailbean.getNumberOfRows(keyword);
            nOfPages = rows / recordsPerPage;
            if (rows % recordsPerPage != 0) {
                nOfPages++;
            }
            if (currentPage > nOfPages && nOfPages != 0) {
                currentPage = nOfPages;
            }

            List<Orderdetail> lists = orderdetailbean.readOrderDetailList(currentPage, recordsPerPage,keyword,direction);
            request.setAttribute("orderdetail", lists);
        } catch (EJBException ex) {
        }

        request.setAttribute("nOfPages", nOfPages);
        request.setAttribute("currentPage", currentPage);
        request.setAttribute("recordsPerPage", recordsPerPage);
        request.setAttribute("keyword", keyword);
        request.setAttribute("direction", direction);
        RequestDispatcher dispatcher = request.getRequestDispatcher("orderdetailpagination.jsp");
        dispatcher.forward(request, response);
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
