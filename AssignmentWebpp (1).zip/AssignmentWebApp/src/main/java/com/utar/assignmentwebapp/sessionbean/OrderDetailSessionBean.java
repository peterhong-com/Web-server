package com.utar.assignmentwebapp.sessionbean;

import com.utar.assignmentwebapp.model.entity.Order;
import com.utar.assignmentwebapp.model.entity.Orderdetail;
import com.utar.assignmentwebapp.model.entity.OrderdetailId;
import com.utar.assignmentwebapp.model.entity.Product;

import javax.ejb.EJBException;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

@Stateless
public class OrderDetailSessionBean implements OrderDetailSessionBeanLocal {
    @PersistenceContext(unitName = "ProductWebApp")
    EntityManager em;

    @Override
    public List<Orderdetail> getAllOrderDetail() {
        Query q =null;
        q=em.createNativeQuery("SELECT * from classicmodels.ORDERDETAILs;");
        return q.getResultList();
    }

    @Override
    public List<Orderdetail> findOrderDetailList(int orid){
        Query q = null;
        q=em.createNativeQuery("SELECT * FROM classicmodels.orderdetails where ordernumber="+orid+";",Orderdetail.class);
        List<Orderdetail> result =q.getResultList();
        return result;
    }

    @Override public int getNumberOfRows(String keyword) throws EJBException {
        Query q = null;
        if (keyword.isEmpty()) {
        q = em.createNativeQuery("SELECT COUNT(*) AS totalrow from classicmodels.orderdetails"); }
    else { q = em.createNativeQuery("SELECT COUNT(*) AS totalrow from classicmodels.orderdetails WHERE concat(ordernumber,orderlinenumber,priceeach,productcode,quantityordered) LIKE ?");
        q.setParameter(1, "%" + keyword + "%"); }
        BigInteger results = (BigInteger) q.getSingleResult();
        int i = results.intValue(); return i; }
    @Override
    public Orderdetail readOrderDetail(int orderId, String productCode) {
        Query q =null;
        q=em.createNativeQuery("SELECT * from classicmodels.ORDERDETAILs WHERE orderNumber= "+orderId +" AND productcode='"+productCode+"';",Orderdetail.class);
        return (Orderdetail) q.getSingleResult();

    }

    @Override
    public void deleteOrderDetail(int orderId, String productCode) {
        Orderdetail a = readOrderDetail(orderId,productCode);
        em.remove(a);
    }
    @Override public List<Orderdetail> readOrderDetailList(int currentPage, int recordsPerPage, String keyword, String direction) throws EJBException { Query q = null; int start = 0; direction = " " + direction; if (keyword.isEmpty()) { q = em.createNativeQuery("SELECT * FROM classicmodels.orderdetails order by ordernumber "+ direction, Orderdetail.class);
        start = currentPage * recordsPerPage - recordsPerPage; } else { q = em.createNativeQuery("SELECT * from classicmodels.orderdetails WHERE concat(ordernumber,orderlinenumber,priceeach,productcode,quantityordered) LIKE ? order by ordernumber"+ direction,Orderdetail.class);
        start = currentPage * recordsPerPage - recordsPerPage;
        q.setParameter(1, "%" + keyword + "%"); }
        List<Orderdetail> results = q.setFirstResult(start).setMaxResults(recordsPerPage).getResultList(); return results; }
    @Override
    public Order findOrder(String orderId) {
        Query q = null;
        int ord= Integer.parseInt(orderId);
        q = em.createNativeQuery("SELECT * from classicmodels.orders WHERE ordernumber ="+ord,Order.class);
        return (Order)q.getSingleResult();

    }
    @Override
    public Product findproduct(String productcode){
        Query q =null;
        q=em.createNativeQuery("SELECT * from classicmodels.products WHERE productcode='"+productcode +"';",Product.class);
        return (Product) q.getSingleResult();
    }

    public void addOrderDetail(String[] s) throws EJBException {

        OrderDetailSessionBeanLocal aa =this;
        Product b = aa.findproduct(s[1]);
        Order a = aa.findOrder(s[0]);
        Orderdetail e = new Orderdetail();
        e.setProductcode(b);
        e.setOrderlinenumber((int) Short.parseShort(s[2]));
        e.setPriceeach(BigDecimal.valueOf(Double.parseDouble(s[3])));
        e.setOrdernumber(a);
        e.setQuantityordered((int) Short.parseShort(s[4]));
        OrderdetailId ab=new OrderdetailId();
        ab.setOrdernumber(a.getId());
        ab.setProductcode(b.getId());
        e.setId(ab);
        em.persist(e);
    }
    public void updateOrderDetail(String[] s) throws EJBException {


        OrderDetailSessionBean aa = this;
        Product b = aa.findproduct(s[1]);
        Order a = aa.findOrder(s[0]);
        Orderdetail e = readOrderDetail(Integer.parseInt(s[0]),s[1]);
        e.setProductcode(b);
        e.setOrderlinenumber((int) Short.parseShort(s[2]));
        e.setPriceeach(BigDecimal.valueOf(Double.parseDouble(s[3])));
        e.setOrdernumber(a);
        e.setQuantityordered((int) Short.parseShort(s[4]));

        em.merge(e);

    }
}
