package com.utar.assignmentwebapp.sessionbean;



import com.utar.assignmentwebapp.model.entity.Order;

import javax.ejb.Local;
import java.util.List;

@Local
public interface OrderSessionBeanLocal {
    public List<Order> getAllOrder();
    public Order readOrder(int orderId);
    public int getNumberOfRows(String keyword);
    public int getNumberOfOrderRows(int cusId);
    public void deleteOrder(int orderId);
    public void cancellShippingOrder(int OrderId);
    public List findOrderList(int cus,int currentPage, int recordsPerPage,  String direction);
    public void addOrder(String s[]);
    public void updateOrder(String s[]);
    public List<Order> readOrderList(int currentPage, int recordsPerPage, String keyword, String direction);
    public Order findNewestOrder();
}
