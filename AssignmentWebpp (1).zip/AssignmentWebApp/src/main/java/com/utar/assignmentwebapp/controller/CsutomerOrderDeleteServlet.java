package com.utar.assignmentwebapp.controller;

import com.utar.assignmentwebapp.sessionbean.OrderSessionBeanLocal;

import javax.ejb.EJB;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "CsutomerOrderDeleteServlet", value = "/CsutomerOrderDeleteServlet")
public class CsutomerOrderDeleteServlet extends HttpServlet {
    @EJB
    private OrderSessionBeanLocal ordbean;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int ordernumber = Integer.parseInt(request.getParameter("ordernumber"));
        ordbean.deleteOrder(ordernumber);
        RequestDispatcher req= request.getRequestDispatcher("CustomerOrderServlet?currentPage=1&recordsPerPage=50&direction=asc");
        req.forward(request,response);
    }


}
