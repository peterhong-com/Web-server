package com.utar.assignmentwebapp.sessionbean;


import com.utar.assignmentwebapp.model.entity.Employee;
import com.utar.assignmentwebapp.model.entity.Office;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigInteger;
import java.util.List;

@Stateless
public class OfficeSessionBean implements OfficeSessionBeanLocal{
    @PersistenceContext(unitName = "ProductWebApp")
    EntityManager em ;
    @Override
    public List<Office> getAllOffice() {
        Query q = null;
        q = em.createNativeQuery("SELECT * from classicmodels.offices");
        List<Office> result = q.getResultList();
        return result;
    }

    @Override
    public List<Office> readOffice(int currentPage, int recordsPerPage, String keyword, String direction) {
        Query q = null;
        int start = 0;
        direction = " " + direction;
        if (keyword.isEmpty()) {
            q = em.createNativeQuery("SELECT * FROM classicmodels.offices order by officecode" + direction, Office.class);
            start = currentPage * recordsPerPage - recordsPerPage;
        } else {
            q = em.createNativeQuery("SELECT * from classicmodels.offices WHERE concat(officecode, city, phone, addressline1, addressline2,state,country,postalcode,territory) LIKE ? order by employeeNumber" + direction, Office.class);
            start = currentPage * recordsPerPage - recordsPerPage;
            q.setParameter(1, "%" + keyword + "%");
        }
        List<Office> results = q.setFirstResult(start).setMaxResults(recordsPerPage).getResultList();
        return results;
    }

    @Override
    public Office findOffice(Integer id) {

        Query q = null;
        q = em.createNativeQuery("SELECT * from classicmodels.offices WHERE officecode='"+id+"';" , Office.class);
        return (Office) q.getSingleResult();
    }
    @Override
    public int getNumberOfRows(String keyword) {
        Query q = null;
        if (keyword.isEmpty()) {
            q = em.createNativeQuery("SELECT COUNT(*) AS totalrow FROM classicmodels.offices");
        } else {
            q = em.createNativeQuery("SELECT COUNT(*) AS totalrow from classicmodels.offices WHERE concat(officecode, city, phone, addressline1, addressline2,state,country,postalcode,territory) LIKE ?");
            q.setParameter(1, "%" + keyword + "%");
        }
        BigInteger results = (BigInteger) q.getSingleResult();
        int i = results.intValue();
        return i;
    }
    @Override
    public void addOffice(String[] s) {
        Office office = new Office();
        Employee employee = new Employee();
        //employee.setId(Integer.valueOf(s[5]));

        office.setId(Integer.valueOf(s[0]));
        office.setCity(s[1]);
        office.setPhone(s[2]);
        office.setAddressline1(s[3]);
        office.setAddressline2(s[4]);
        office.setState(s[5]);
        office.setCountry(s[6]);
        office.setPostalcode(s[7]);
        office.setTerritory(s[8]);
        em.persist(employee);
    }
    @Override
    public void deleteOffice(Integer id) {
        Office delete = findOffice(id);
        em.remove(delete);

    }
    @Override
    public void updateOffice(String[] s) {
        Office office = findOffice(Integer.valueOf(s[0]));
        Employee employee = new Employee();
        //employee.setId(Integer.valueOf(s[5]));

        office.setCity(s[1]);
        office.setPhone(s[2]);
        office.setAddressline1(s[3]);
        office.setAddressline2(s[4]);
        office.setState(s[5]);
        office.setCountry(s[6]);
        office.setPostalcode(s[7]);
        office.setTerritory(s[8]);
        em.merge(office);
    }



}
