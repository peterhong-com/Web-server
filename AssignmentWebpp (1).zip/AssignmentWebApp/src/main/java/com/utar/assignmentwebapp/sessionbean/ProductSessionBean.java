package com.utar.assignmentwebapp.sessionbean;

import com.utar.assignmentwebapp.model.entity.Order;
import com.utar.assignmentwebapp.model.entity.Product;
import com.utar.assignmentwebapp.model.entity.Productline;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

@Stateless
public class ProductSessionBean implements ProductSessionBeanLocal {
    @PersistenceContext(unitName = "ProductWebApp")
    EntityManager em ;
    @Override
    public List<Product> getAllProduct() {
        Query q = null;
        q = em.createNativeQuery("SELECT * from classicmodels.products");
        List<Product> result = q.getResultList();
        return result;
    }

    @Override
    public List<Product> readProductList(int currentPage, int recordsPerPage, String keyword, String direction) {
        Query q = null;
        int start = 0;
        direction = " " + direction;
        if (keyword.isEmpty()) {
            q = em.createNativeQuery("SELECT * FROM classicmodels.products order by productcode" + direction, Product.class);
            start = currentPage * recordsPerPage - recordsPerPage;
        } else {
            q = em.createNativeQuery("SELECT * from classicmodels.products WHERE concat(productcode, productname,productline, productscale, productvendor, productdescription) LIKE ? order by productcode" + direction, Product.class);
            start = currentPage * recordsPerPage - recordsPerPage;
            q.setParameter(1, "%" + keyword + "%");
        }
        List<Product> results = q.setFirstResult(start).setMaxResults(recordsPerPage).getResultList();
        return results;
    }

    @Override
    public Product findProduct(String id) {

        Query q = null;
        q = em.createNativeQuery("SELECT * from classicmodels.products WHERE productcode='"+id+"';" , Product.class);
        return (Product) q.getSingleResult();
    }

    @Override
    public int getNumberOfRows(String keyword) {
        Query q = null;
        if (keyword.isEmpty()) {
            q = em.createNativeQuery("SELECT COUNT(*) AS totalrow FROM classicmodels.products");
        } else {
            q = em.createNativeQuery("SELECT COUNT(*) AS totalrow from classicmodels.products WHERE concat(productcode, productname, productscale, productvendor, productdescription) LIKE ?");
            q.setParameter(1, "%" + keyword + "%");
        }
        BigInteger results = (BigInteger) q.getSingleResult();
        int i = results.intValue();
        return i;
    }

    @Override
    public void deleteProduct(String id) {
        Product delete = findProduct(id);
        em.remove(delete);

    }

    @Override
    public void addProduct(String[] s) {
        Product p = new Product();
        Productline productline = new Productline();
        productline.setId(s[8]);

        p.setId(s[0]);
        p.setProductname(s[1]);
        p.setProductscale(s[2]);
        p.setProductvendor(s[3]);
        p.setProductdescription(s[4]);
        p.setProductline(productline);
        p.setQuantityinstock(Integer.parseInt(s[5]));
        p.setBuyprice(BigDecimal.valueOf(Double.parseDouble(s[6])));
        p.setMsrp(BigDecimal.valueOf(Double.parseDouble(s[7])));
        em.persist(p);
    }
    @Override
    public void updateProduct(String[] s) {
        Product p = findProduct((s[0]));
        Productline productline = new Productline();
        productline.setId(s[8]);

        p.setProductname(s[1]);
        p.setProductscale(s[2]);
        p.setProductvendor(s[3]);
        p.setProductline(productline);
        p.setProductdescription(s[4]);
        p.setQuantityinstock(Integer.parseInt(s[5]));
        p.setBuyprice(BigDecimal.valueOf(Double.parseDouble(s[6])));
        p.setMsrp(BigDecimal.valueOf(Double.parseDouble(s[7])));
        em.merge(p);
    }


}
