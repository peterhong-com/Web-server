package com.utar.assignmentwebapp.controller;

import com.utar.assignmentwebapp.model.entity.Customer;
import com.utar.assignmentwebapp.sessionbean.CustomerSessionBeanLocal;
import com.utar.assignmentwebapp.utilities.ValidateCustomerManageLogic;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "CustomerController", value = "/CustomerController")
public class CustomerController extends HttpServlet{

    @EJB
    private CustomerSessionBeanLocal empbean;


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String customernumber = request.getParameter("customernumber");
        try {
            Customer customer = empbean.findCustomer(customernumber);
            request.setAttribute("customer", customer);
            RequestDispatcher req = request.getRequestDispatcher("CustView.jsp");
            req.forward(request, response);
        } catch (EJBException ex) {
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String customernumber = request.getParameter("customernumber");
        String customername= request.getParameter("customername");
        String contactlastname = request.getParameter("contactlastname");
        String contactfirstname= request.getParameter("contactfirstname");
        String phone= request.getParameter("phone");
        String addressline1= request.getParameter("addressline1");
        String addressline2= request.getParameter("addressline2");
        String city= request.getParameter("city");
        String state= request.getParameter("state");
        String postal= request.getParameter("postal");
        String country= request.getParameter("country");
        String salesrepen= request.getParameter("salesrepen");
        String creditnumber= request.getParameter("creditnumber");



        PrintWriter out = response.getWriter();


        String[] s = {customernumber, customername, contactlastname, contactfirstname, phone, addressline1, addressline2, city, state, postal, country, salesrepen, creditnumber};

        try {
            if (ValidateCustomerManageLogic.validateManager(request).equals("UPDATE")) {
                empbean.updateCustomer(s);
            }
            else if (ValidateCustomerManageLogic.validateManager(request).equals("DELETE")) {
                empbean.deleteCustomer(Integer.parseInt(customernumber));
            }
            else{
                //empbean.addCustomer(s);
                ValidateCustomerManageLogic.navigateDoneJS(out);
            }
            ValidateCustomerManageLogic.navigateJS(out);
        } catch (EJBException ex) {
            ValidateCustomerManageLogic.navigateWrongJS(out);
        }




    }
}
