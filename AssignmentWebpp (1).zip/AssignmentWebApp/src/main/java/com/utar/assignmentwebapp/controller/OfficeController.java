package com.utar.assignmentwebapp.controller;


import com.utar.assignmentwebapp.model.entity.Employee;
import com.utar.assignmentwebapp.model.entity.Office;
import com.utar.assignmentwebapp.sessionbean.EmployeeSessionBeanLocal;
import com.utar.assignmentwebapp.sessionbean.OfficeSessionBeanLocal;
import com.utar.assignmentwebapp.utilities.ValidateEmployeeManageLogic;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "OfficeController", value = "/OfficeController")
public class OfficeController extends HttpServlet {

    @EJB
    private OfficeSessionBeanLocal employeebean;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("officecode");
        try {
            Office office = employeebean.findOffice(Integer.valueOf(id));
            request.setAttribute("staffs", office);
            RequestDispatcher req = request.getRequestDispatcher("OfficeDetails.jsp");
            req.forward(request, response);
        } catch (EJBException ex) {
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("officecode");
        String city = request.getParameter("city");
        String phone = request.getParameter("phone");
        String addressline1 = request.getParameter("addressline1");
        String addressline2 = request.getParameter("addressline2");
        String state = request.getParameter("state");
        String country = request.getParameter("country");
        String postalcode = request.getParameter("postalcode");
        String territory = request.getParameter("territory");

        PrintWriter out = response.getWriter();
        // this line is to package the whole values into one array string variable -
        // easier just pass one parameter object
        String[] s = {id,city, phone, addressline1, addressline2, state,country,postalcode,territory };


        try {
            if (ValidateEmployeeManageLogic.validateManager(request).equals("UPDATE")) {
                // call session bean updateEmployee method
                employeebean.updateOffice(s);

            }
            else if (ValidateEmployeeManageLogic.validateManager(request).equals("DELETE")) {
                // call session bean deleteEmployee method
                employeebean.deleteOffice(Integer.valueOf(id));
                // if ADD button is clicked
            } else {
                // call session bean addEmployee method
                employeebean.addOffice(s);
            }
            // this line is to redirect to notify record has been updated and redirect to
            // another page
            ValidateEmployeeManageLogic.navigateJS(out);
        } catch (EJBException ex) {
            ValidateEmployeeManageLogic.navigateWrongJS(out);
        }

    }
}
