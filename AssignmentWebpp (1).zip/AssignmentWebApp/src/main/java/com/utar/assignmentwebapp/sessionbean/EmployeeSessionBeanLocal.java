package com.utar.assignmentwebapp.sessionbean;

import com.utar.assignmentwebapp.model.entity.Employee;

import javax.ejb.Local;
import java.util.List;


@Local
public interface EmployeeSessionBeanLocal {
    public List<Employee> getAllEmployee();
    public Employee findEmployee(Integer id) ;
    public List<Employee> readEmployee(int currentPage, int recordsPerPage, String keyword, String direction);
    public int getNumberOfRows(String keyword) ;
    public void updateEmployee(String[] s) ;
    public void deleteEmployee(Integer id) ;
    public void addEmployee(String[] s) ;
}
