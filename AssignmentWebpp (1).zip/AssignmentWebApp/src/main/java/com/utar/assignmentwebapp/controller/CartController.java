package com.utar.assignmentwebapp.controller;

import com.utar.assignmentwebapp.model.entity.Product;
import com.utar.assignmentwebapp.sessionbean.CartSessionBeanLocal;
import com.utar.assignmentwebapp.sessionbean.ProductSessionBeanLocal;
import com.utar.assignmentwebapp.utilities.ValidateEmployeeManageLogic;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "CartController", value = "/CartController")
public class CartController extends HttpServlet {
    @EJB
    private ProductSessionBeanLocal empbean;

    private CartSessionBeanLocal cartbean;



    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String productcode = request.getParameter("productcode");
        try {
            Product product = empbean.findProduct(productcode);
            request.setAttribute("Pro", product);
            RequestDispatcher req = request.getRequestDispatcher("AddCart.jsp");
            req.forward(request, response);
        } catch (EJBException ex) {
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pid = request.getParameter("productcode");
        String pname = request.getParameter("productname");
        Double quantity = Double.valueOf(request.getParameter("quantity"));
        Double price = Double.valueOf(request.getParameter("priceperunit"));

        PrintWriter out = response.getWriter();
        // this line is to package the whole values into one array string variable -
        // easier just pass one parameter object
        String[] s = { pid,pname};
        Double[]y = {quantity,price};


        try {
            if (ValidateEmployeeManageLogic.validateManager(request).equals("ORDER")) {
                // call session bean updateEmployee method
               cartbean.createTable();
               cartbean.addCart(s,y);
            }
            else  {

            }
            // this line is to redirect to notify record has been updated and redirect to
            // another page
            ValidateEmployeeManageLogic.navigateJS(out);
        } catch (EJBException ex) {
        }
    }


}
