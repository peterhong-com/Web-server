package com.utar.assignmentwebapp.controller;

import com.utar.assignmentwebapp.model.entity.Customer;
import com.utar.assignmentwebapp.sessionbean.CustomerSessionBeanLocal;
import com.utar.assignmentwebapp.utilities.ValidateAddCustManageLogic;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "CustRegServlet", value = "/CustRegServlet")
public class CustRegServlet extends HttpServlet {
    @EJB
    private CustomerSessionBeanLocal emp;
    Customer cust;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String customername= request.getParameter("customername");
        String contactlastname = request.getParameter("contactlastname");
        String contactfirstname= request.getParameter("contactfirstname");
        String phone= request.getParameter("phone");
        String addressline1= request.getParameter("addressline1");
        String addressline2= request.getParameter("addressline2");
        String city= request.getParameter("city");
        String state= request.getParameter("state");
        String postal= request.getParameter("postal");
        String country= request.getParameter("country");
        String salesrepen= request.getParameter("salesrepen");
        String creditnumber= request.getParameter("creditnumber");

        PrintWriter out = response.getWriter();

        cust = emp.findNewestCust();
        int customernumber = cust.getId()+1;


        String[] s = {String.valueOf(customernumber), customername, contactlastname, contactfirstname, phone, addressline1, addressline2, city, state, postal, country, salesrepen, creditnumber};

        try {
            emp.addCustomer(s);
            request.setAttribute("custnum", customernumber);
            RequestDispatcher req = request.getRequestDispatcher("CustNum.jsp");
            req.forward(request, response);
        } catch (EJBException ex) {
            ValidateAddCustManageLogic.navigateWrongJS(out);
        }

    }
}
