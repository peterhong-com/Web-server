package com.utar.assignmentwebapp.controller;

import com.utar.assignmentwebapp.model.entity.Employee;
import com.utar.assignmentwebapp.sessionbean.EmployeeSessionBeanLocal;
import com.utar.assignmentwebapp.utilities.ValidateEmployeeManageLogic;

import javax.ejb.EJB;
import javax.ejb.EJBException;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "EmployeeController", value = "/EmployeeController")
public class EmployeeController extends HttpServlet {

    @EJB
    private EmployeeSessionBeanLocal employeebean;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("employeenumber");
        try {
            Employee employee = employeebean.findEmployee(Integer.valueOf(id));
            request.setAttribute("staffs", employee);
            RequestDispatcher req = request.getRequestDispatcher("employeeUpdate.jsp");
            req.forward(request, response);
        } catch (EJBException ex) {
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("employeenumber");
        String firstname = request.getParameter("firstname");
        String lastname = request.getParameter("lastname");
        String extension = request.getParameter("extension");
        String email = request.getParameter("email");
        String officecode = request.getParameter("officecode");
        String reportsto = request.getParameter("reportsto");
        String jobtitle = request.getParameter("jobtitle");

        PrintWriter out = response.getWriter();
        // this line is to package the whole values into one array string variable -
        // easier just pass one parameter object
        String[] s = {id,firstname, lastname, extension, email, officecode,reportsto,jobtitle };


        try {
            if (ValidateEmployeeManageLogic.validateManager(request).equals("UPDATE")) {
                // call session bean updateEmployee method
                employeebean.updateEmployee(s);

            }
            else if (ValidateEmployeeManageLogic.validateManager(request).equals("DELETE")) {
                // call session bean deleteEmployee method
                employeebean.deleteEmployee(Integer.valueOf(id));
                // if ADD button is clicked
            } else {
                // call session bean addEmployee method
                employeebean.addEmployee(s);
            }
            // this line is to redirect to notify record has been updated and redirect to
            // another page
            ValidateEmployeeManageLogic.navigateJS(out);
        } catch (EJBException ex) {
            ValidateEmployeeManageLogic.navigateWrongJS(out);
        }

    }
}
